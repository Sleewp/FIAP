let nome = "Fiap";
let sobrenome = "Brasil";
let numero_01 = 10;
let numero_02 = 20.5;

console.log("Nome:",nome);
console.log("Sobrenome: ",sobrenome);
console.log("Número 01: ",numero_01);
console.log("Número 02: ",numero_02);

/* Criar uma variável */
let valor = 100;

/* Exibir o tipo de dado da variável */
console.log("Tipo de dado da variável valor: ",typeof(valor));

/* Alterar o valor da variável */
valor = "Texto";

/* Exibir o tipo de dado da variável */
console.log("Tipo de dado da variável valor: ",typeof(valor));

const a = [valor];

const estado = "São Paulo";
console.log("Estado: ",estado);

const usuario = {nome: "João da Silva",idade: 18};

usuario.nome = "João da Silva Junior";
console.log("O nome do usuário é:",usuario.nome,". Ele tem",usuario.idade,"anos.");